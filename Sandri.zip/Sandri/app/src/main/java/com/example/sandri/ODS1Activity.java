package com.example.sandri;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ODS1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ods1);
    }
}


